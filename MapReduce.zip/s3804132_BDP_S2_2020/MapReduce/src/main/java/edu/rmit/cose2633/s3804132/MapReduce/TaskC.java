package edu.rmit.cose2633.s3804132.MapReduce;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class TaskC {
	private static final Logger LOG = Logger.getLogger(TaskB.class);

	public static class TaskCMapper extends Mapper<Object, Text, Text, IntWritable> {
//Associated data structure  to combine total occurance of the word for each mapper
		Map<String, Integer> associateDataStruct = new HashMap<String, Integer>();

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			StringTokenizer itr = new StringTokenizer(value.toString());
			// Set log-level to INFO
			LOG.setLevel(Level.INFO);
			LOG.info("The Mapper task of Gowtham Raghavendran, s3804132");
			while (itr.hasMoreTokens()) {
				String word = itr.nextToken();
				if (associateDataStruct.containsKey(word)) {
					int sum = (int) associateDataStruct.get(word) + 1;
					associateDataStruct.put(word, sum);
				} else {
					associateDataStruct.put(word, 1);
				}
			}
		}

		public void cleanup(Context context) throws IOException, InterruptedException {
			Iterator<Map.Entry<String, Integer>> iterator = associateDataStruct.entrySet().iterator();

			// Setting up the cumulative word count of each count and sending it to the reducer
			while (iterator.hasNext()) {
				Map.Entry<String, Integer> entry = iterator.next();
				String word = entry.getKey() + "";
				Integer count = entry.getValue();
				context.write(new Text(word), new IntWritable(count));
			}
		}
	}

	public static class TaskCReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			LOG.setLevel(Level.INFO);
			LOG.info("The Reducer task of Gowtham Raghavendran, s3804132");
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}

	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "TaskC");
		job.setJarByClass(TaskC.class);
		job.setMapperClass(TaskCMapper.class);
		job.setCombinerClass(TaskCReducer.class);
		job.setReducerClass(TaskCReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
