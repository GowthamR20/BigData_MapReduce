package edu.rmit.cose2633.s3804132.MapReduce;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class TaskD extends Configured implements Tool {
	private static final Logger LOG = Logger.getLogger(TaskD.class);

	public static class TaskDMapper extends Mapper<Object, Text, Text, IntWritable> {
		private final IntWritable one = new IntWritable(1);
		private Text wordType = new Text();

		@Override
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

			// Set log-level to INFO
			LOG.setLevel(Level.INFO);
			LOG.info("The Mapper task of Gowtham Raghavendran, s3804132");
			try {
				StringTokenizer itr = new StringTokenizer(value.toString());
				// condition to check the word type for each word based on its length

				while (itr.hasMoreTokens()) {
					String word = itr.nextToken();
					if (word.length() >= 1 && word.length() <= 4) {
						wordType = new Text("Short: ");
					} else if (word.length() >= 5 && word.length() <= 7) {
						wordType = new Text("Medium: ");
					} else if (word.length() >= 8 && word.length() <= 10) {
						wordType = new Text("Long: ");
					} else {
						wordType = new Text("Extra Long: ");
					}
					context.write(wordType, one);
				}

			} catch (Exception ex) {
				LOG.error("Caught Exception", ex);
			}
		}
	}

	public static class TaskDPartitioner extends Partitioner<Text, IntWritable> {
// partioner function to partition the word to a specific reducer
		// 0 - reducer 1
		// 1 - reducer 2
		@Override
		public int getPartition(Text key, IntWritable value, int numReduceTasks) {
			String wrd = key.toString();
			if (numReduceTasks == 0) {
				return 0;
			}

			if (wrd.contains("Short") || wrd.contains("Extra Long")) {
				return 0;
			} else {
				return 1 % numReduceTasks;
			}
		}
	}

	public static class TaskDReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		protected void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			LOG.setLevel(Level.INFO);
			LOG.info("The Mapper task of Gowtham Raghavendran, s3804132");

			IntWritable result = new IntWritable();
			LOG.setLevel(Level.DEBUG);

			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
		System.exit(ToolRunner.run(new TaskD(), args));
	}

	public int run(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "TaskD");

		FileInputFormat.setInputPaths(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.setJarByClass(TaskD.class);
		job.setMapperClass(TaskDMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);
		job.setPartitionerClass(TaskDPartitioner.class);
		job.setReducerClass(TaskDReducer.class);
		job.setNumReduceTasks(2);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		System.exit(job.waitForCompletion(true) ? 0 : 1);
		return 0;

	}
}
