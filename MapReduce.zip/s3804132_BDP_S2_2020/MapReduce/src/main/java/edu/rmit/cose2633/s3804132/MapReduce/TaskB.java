package edu.rmit.cose2633.s3804132.MapReduce;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class TaskB {
	private static final Logger LOG = Logger.getLogger(TaskB.class);
	public static class TaskBMapper extends Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);
		private Text wordType = new Text();

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			// Set log-level to INFO
			LOG.setLevel(Level.INFO);
			LOG.info("The Mapper task of Gowtham Raghavendran, s3804132");
			StringTokenizer itr = new StringTokenizer(value.toString());
			// condition to check if the word starts with a vowel or a consonent
			while (itr.hasMoreTokens()) {
				String text = itr.nextToken();
				text = text.toLowerCase();
				if (text.startsWith("a") || text.startsWith("e") || text.startsWith("i") || text.startsWith("o")
						|| text.startsWith("u")) {
					wordType = new Text("Vowel Word:	");
				} else {
					wordType = new Text("Consonent Word:	");
				}
				context.write(wordType, one);
			}
		}
	}

	public static class TaskBReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			LOG.setLevel(Level.INFO);
			LOG.info("The Reducer task of Gowtham Raghavendran, s3804132");
			int sum = 0;
			// aggregating the count value of the same word in the file
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "TaskB");
		job.setJarByClass(TaskB.class);
		job.setMapperClass(TaskBMapper.class);
		job.setCombinerClass(TaskBReducer.class);
		job.setReducerClass(TaskBReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
