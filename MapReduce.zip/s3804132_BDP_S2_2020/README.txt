
Assignment 1 Big Data Processing

Gowtham Raghavendran
s3804132


The maven project contains classes for Task 1-4 of MapReduce application.

Running each tasks:
Place the jar file in the user/s3804132 path and the input files under /user/s3804132/inputFile path


Task A:
Copy the jar file from HDFS to the cluster:
hadoop fs -copyToLocal /user/s3804132/TaskA.jar

Run the Jar folder with the input files under /user/s3804132/inputFile and to display the output in the output1 folder
hadoop jar TaskA.jar edu.rmit.cose2633.s3804132.MapReduce.TaskA /user/s3804132/inputFile /user/3804132/output1

Task B:
Copy the jar file from HDFS to the cluster:
hadoop fs -copyToLocal /user/s3804132/TaskB.jar

Run the Jar folder with the input files under /user/s3804132/inputFile and to display the output in the output1 folder
hadoop jar TaskB.jar edu.rmit.cose2633.s3804132.MapReduce.TaskB /user/s3804132/inputFile /user/3804132/output2

Task C:
Copy the jar file from HDFS to the cluster:
hadoop fs -copyToLocal /user/s3804132/TaskC.jar

Run the Jar folder with the input files under /user/s3804132/inputFile and to display the output in the output1 folder
hadoop jar TaskC.jar edu.rmit.cose2633.s3804132.MapReduce.TaskC /user/s3804132/inputFile /user/3804132/output3

Task D:
Copy the jar file from HDFS to the cluster:
hadoop fs -copyToLocal /user/s3804132/TaskD.jar

Run the Jar folder with the input files under /user/s3804132/inputFile and to display the output in the output1 folder
hadoop jar TaskD.jar edu.rmit.cose2633.s3804132.MapReduce.TaskD /user/s3804132/inputFile /user/3804132/outputD



To Boost the number of nodes in the cluster:
Initially the cluster will have 3 nodes by default. Boosting the cluster will add two extra task nodes to it.
1	Enter inside the cluster and run ./boost_cluster.sh to add two new nodes to the existing cluster
copy the provided file into /user/s3804132 using the following command:
hadoop distcp s3a://commoncrawl/crawl-data/CC-MAIN-2018-17/segments/1524125936833.6/wet/CC-MAIN-20180419091546-20180419111546-00036.warc.wet.gz /user/s3804132/

2	Run the TaskA as mentioned previously but providing the input	 file as the one mentioned above:
hadoop jar TaskA.jar edu.rmit.cose2633.s3804132.MapReduce.TaskA /user/s3804132/CC-MAIN-20180419091546-20180419111546-00036.warc.wet.gz /user/s3804132/output1Boost

Repeat the above steps to run using 5 and 7 nodes(boost each time) but with different output folder path.
From the experiment above we can see that:
Nodes	Mapper CUP_Millisecond  	Reducer CUP_Millisecond 	Mapper CUP_Millisecond
3	72430					2400			74830
5	74220					2060			76280
7	73400					2440			75840
From the reading of CPU time we can say that the CUP Millisecond is varying for different nodes but eventually is decreased when nodes are more. This is because the tasks are split to
different nodes and run simultaneously therby decreasing the running time.